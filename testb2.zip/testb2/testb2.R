#lokasi penyimpanan
setwd("E:/wd/testb2")

#dataset yang digunakan
dataset <- read.csv("kohkiloyeh.csv", sep = ";")

#deskripsi dataset
View(dataset)
summary(dataset)
str(dataset)

#packages yang digunakan
library(C50)
library(printr)

#mejadikan kolom faktor
dataset$pb <- as.factor(dataset$pb)

#membuat model
model <- C5.0(pb ~., data=dataset)

#melihat hasil model
model
summary(model)

#gambar model
plot(model)

#melihat isi dataset
fix(dataset)

#membuat datatesting
datatesting <- dataset[,1:5]

#membuat prediksi
predictions <- predict(model, datatesting)

#bandingkan hasil prediksi dengan dataset
table(predictions, dataset$pb)
